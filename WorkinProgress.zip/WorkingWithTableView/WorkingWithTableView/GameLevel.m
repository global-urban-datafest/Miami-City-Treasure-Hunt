//
//  GameLevel.m
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import "GameLevel.h"

@implementation GameLevel

@synthesize items, levelName;

- (id) initWithName: (NSString *) name{
    self = [super init];
    if (self) {
        items = [[NSMutableArray alloc] init];
        levelName = [NSString stringWithString:name];
    }
    return self;
}


@end
