//
//  main.m
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TVCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([TVCAppDelegate class]));
    }
}
