//
//  XMLParser.m
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import "XMLParser.h"

@interface XMLParser ()

@property NSXMLParser *parser;
@property NSString *element;

@end

@implementation XMLParser

@synthesize parentParserDelegate;

-(void)loadDataFromXML
{
    
    NSString *path = [[NSBundle mainBundle] pathForResource:@"appXmlData"
                                                     ofType:@"xml"];
    
    NSData *data = [NSData dataWithContentsOfFile:path];
    
    self.parser = [[NSXMLParser alloc] initWithData: data];
    self.parser.delegate = self;
    [self.parser parse];
}

- (void)parser:(NSXMLParser *)parser
didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI
 qualifiedName:(NSString *)qName {
    
    self.element = elementName;
}

- (void) parser:(NSXMLParser *)parser
didStartElement:(NSString *)elementName
   namespaceURI:(NSString *)namespaceURI
  qualifiedName:(NSString *)qualifiedName
     attributes:(NSDictionary *)attributeDict {
    
    if ([elementName isEqualToString:@"DataSource"]) {
        [parser setDelegate:parentParserDelegate];
    }
    if ([elementName isEqualToString:@"ArtsCulture"]) {
        game = [[GameClass alloc] initWithCategories];        
    }
    if ([elementName isEqualToString:@"Site"]) {
        categories = [[CategoryItems alloc] initWithName:[attributeDict valueForKey:@"title"]];
        [game.categories addObject:categories];
    }
    if ([elementName isEqualToString:@"Piece"]) {
        levels = [[GameLevel alloc] initWithName:[attributeDict valueForKey:@"name"]];
        [categories.levels addObject:levels];
    }
    if ([elementName isEqualToString:@"Item"]) {
        /*items = [[TreasureHuntItems alloc] initWithImage: [attributeDict valueForKey:@"link"]
                                                 andName:[attributeDict valueForKey:@"name"]
                                                 andInfo:[attributeDict valueForKey:@"info"]
                                             andLocation:[attributeDict valueForKey:@"location"]
                                               andArtist:[attributeDict valueForKey:@"artist"]];*/
        [levels.items addObject: items];
    }
    //self.element = nil;
}

@end

























