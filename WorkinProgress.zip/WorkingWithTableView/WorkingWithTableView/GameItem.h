//
//  GameItem.h
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CategoryItems.h"
#import "LoadData.h"

@interface GameItem : NSObject{
    NSMutableArray *categories;
}

@property (strong, nonatomic) NSMutableArray *categories;

- (id) initWithCategories;

@end
