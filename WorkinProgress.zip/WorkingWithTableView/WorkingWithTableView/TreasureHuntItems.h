//
//  TreasureHuntItems.h
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TreasureHuntItems : NSObject{
    NSString *image;
    NSString *name;
    NSString *location;
    NSString *info;
    NSString *artist;
}

@property (strong, nonatomic) NSString *image;

@property (strong, nonatomic) NSString *name;

@property (strong, nonatomic) NSString *location;

@property (strong, nonatomic) NSString *info;

@property (strong, nonatomic) NSString *artist;

- (id) initWithImage: (NSString *) imageI andName: (NSString *) nameI andLocation: (NSString *) locationI andArtist: (NSString *) artistI andInfo: (NSString *) infoI;

@end
