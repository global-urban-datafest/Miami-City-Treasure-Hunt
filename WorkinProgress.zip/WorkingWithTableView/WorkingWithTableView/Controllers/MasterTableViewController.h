//
//  MasterTableViewController.h
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/8/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GameClass.h"
#import "LoadData.h"
#import "LevelTableViewController.h"

@interface MasterTableViewController : UITableViewController{
    GameClass *myGame;
    LoadData *myData;
}

@end
