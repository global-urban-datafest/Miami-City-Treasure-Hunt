//
//  QRCodeViewController.m
//  ParserDemo
//
//  Created by Bryan De Castro  on 3/7/15.
//  Copyright (c) 2015 Josh Newman. All rights reserved.
//

#import "QRCodeViewController.h"



@interface QRCodeViewController ()

+ (BOOL)isAvailableForServiceType:(NSString *)serviceType;

+(SLComposeViewController*)composeViewControllerForServiceType:(NSString*) serviceType;


@end

@implementation QRCodeViewController


@synthesize imgPicker,resultTextView,resultImageView;




- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/


-(IBAction)StartScan:(id) sender
{
    NSLog(@"Scanning..");
    resultTextView.text = @"Scanning..";
    
    ZBarReaderViewController *codeReader = [ZBarReaderViewController new];
    codeReader.readerDelegate=self;
    codeReader.supportedOrientationsMask = ZBarOrientationMaskAll;
    
    ZBarImageScanner *scanner = codeReader.scanner;
    [scanner setSymbology: ZBAR_I25 config: ZBAR_CFG_ENABLE to: 0];
    
    [self presentViewController:codeReader animated:YES completion:nil];
    
}

- (void) readerControllerDidFailToRead: (ZBarReaderController*) reader
                             withRetry: (BOOL) retry{
    NSLog(@"the image picker failing to read");
    
}

- (void) imagePickerController: (UIImagePickerController*) reader didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    
    //  get the decode results
    id<NSFastEnumeration> results = [info objectForKey: ZBarReaderControllerResults];
    
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        // just grab the first barcode
        break;
    
    // showing the result on textview
    resultTextView.text = symbol.data;
    
    resultImageView.image = [info objectForKey: UIImagePickerControllerOriginalImage];
    
    // dismiss the controller
    [reader dismissViewControllerAnimated:YES completion:nil];
}


//Facebook Button to post to your Facebook Page.

- (IBAction)postToFacebook:(id)sender {
    
    
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeFacebook]) {
        SLComposeViewController *fbComposer = [SLComposeViewController
                                               composeViewControllerForServiceType:SLServiceTypeFacebook];
        
        NSString *resultText = resultTextView.text;
        
        //set the initial text message
        [fbComposer setInitialText: resultText];
        //add url
        //if ([fbComposer addURL:[NSURL URLWithString:@"www.kmithi.blogspot.com"]]) {
       //     NSLog(@"Blog url added");
        //}
        
        
        // you can remove all added URLs as follows
        [fbComposer removeAllURLs];
        
        //add image to post
        if ([fbComposer addImage:[UIImage imageNamed:@"econoBadge1.png"]]) {
            NSLog(@"Trophy has been added to the post");
        }
       // if ([fbComposer addImage:[UIImage imageNamed: @"scan.jpg"]]) {
       //     NSLog(@"scan is added to the post");
       // }
        
        //remove all added images
        //[fbComposer removeAllImages];
        
        //present the composer to the user
        [self presentViewController:fbComposer animated:YES completion:nil];
        
    }else {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Facebook Error"
                                  message:@"You may not have set up facebook service on your device or\n                                  You may not connected to internet.\nPlease check ..."
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles: nil];
        [alertView show];
    }
}





@end
