//
//  LoadData.m
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import "LoadData.h"

@implementation LoadData

- (GameClass *) loadData
{
    myGame = [[GameClass alloc] initWithCategories];
    
    categories = [[CategoryItems alloc] initWithName: @"Arts & Culture"];
    categories2 = [[CategoryItems alloc] initWithName: @"Nature"];
    categories3 = [[CategoryItems alloc] initWithName: @"Music"];
    
    [myGame.categories addObject:categories];
    [myGame.categories addObject:categories2];
    [myGame.categories addObject:categories3];
    
    
    
    
    // items for category 1 Level 1
    cat1Level1Item1 = [[TreasureHuntItems alloc] initWithImage:@"http://www.miamidadepublicart.org/app2/sites/default/files/styles/195x160/public/object-thumbs/Atea-1.jpg?itok=GRluyBR7" andName:@"Atea" andLocation:@"Miami International Airport, Concourse E Satellite Building, Gates 22-23" andArtist:@"Beasley, Bruce" andInfo: @"In the late 1970s, artist Bruce Beasley turned back to working with metal--after a decade of working with cast acrylics as his medium--exploring a more formal geometry with a series of large sculptures produced in both stainless steel and aluminum.  He created a number of monumental commissions for public institutions including the San Francisco International Airport, Stanford University; the State of California; the State of Alaska; the City of Eugene, Oregon; and Grounds for Sculpture in Hamilton, New Jersey.  Amongst them is Atea , which he created for the Miami International Airport in 1977.Born in Los Angles. Bruce Beasley attended Dartmouth College before completing his B.A. at the University of California, Berkeley in 1962. His work can be found in museums and public collections internationally, including the Museum of Modern Art, New York, the Solomon R. Guggenheim Museum, the Djerassi Foundation, and in the collection of Kleinewefers GmbH, Krefeld, Germany."];
    
    
    
    cat1Level1Item2 = [[TreasureHuntItems alloc] initWithImage:@"http://www.miamidadepublicart.org/app2/sites/default/files/styles/lightbox/public/collection-images/Main_Image-Janney_%282%29.jpg?itok=-uti186c" andName:@"Harmonic Convergence" andLocation:@"Miami International Airport, Concourse D" andArtist:@"Janney, Christopher" andInfo:@"Harmonic Convergence  incorporates an interactive sound environment with diagonal patterns of colored glass that are integrated into the Mover Station Terminal Connector. As people navigate through the space, their activity influences the melodic layering of natural sound environments created from tropical birds, distant thunder storms, sounds of the Everglades and other environments indigenous to South Florida. As sunlight transitions throughout the space, the colored, diagonal shaped exterior glass casts dramatic, constantly changing shadow patterns across the floor. Christopher Janney has toured the United States and Europe with his interactive sound/architecture installations, and his performance pieces have been appreciated by audiences worldwide. His individual artworks, as well as his collaborations have made him the recipient of awards and grants over the course of his artistic career, including a grant from the National Endowment for the Arts in 1991 and the Edison Award from General Electric for innovation in design in 1995. Janney is a Visiting Professor at The Cooper Union School of Architecture in New York City, where he teaches his course, Sound as a Visual Medium . He resides in Lexington, Massachusetts."];

    
    
    cat1Level1Item3 = [[TreasureHuntItems alloc] initWithImage:@"http://www.miamidadepublicart.org/app2/sites/default/files/styles/lightbox/public/collection-images/Lipski_1.JPG?itok=K01fRVQN" andName:@"Got Any Jacks?" andLocation:@"Miami International Airport, Concourse D Terminal Extension" andArtist:@"Lipski, Donald" andInfo:@"Consisting of nearly 100 sculptures made of fish replicas, Got Any Jacks? is a tribute to Miami’s miraculous aquatic environment. The fish replicas, ranging in size from two feet across to over fourteen feet across, are arranged in abstract, geometric patterns. Their unique arrangement throughout the concourse walls evokes sculptures that are at once fish, and as abstract shapes, represent something else.Artists the artist states, I appreciate it when I get off a plane, and walking into the airport, get a feeling of where I’ve landed. Miami has big nature: blue skies, billowing clouds, sparkling water, vivid colors, and a certain degree of levity. I want travelers to have a big experience before they leave the airport. I hope I’ve created an environment full of delight, beauty and surprise.To fabricate the fish, Lipski collaborated with renowned taxidermist Mike Kirkhart, who has won numerous awards, including Best in World, Master Taxidermy, three separate years, by the National Taxidermy Association. To complete Got Any Jacks?, Kirkhart solely dedicated the expertise and creativity of his shop, New Wave Taxidermy, exclusively to this project for one year."];
    
    
    
    cat1Level1Item4 = [[TreasureHuntItems alloc] initWithImage:@"http://www.miamidadepublicart.org/app2/sites/default/files/styles/lightbox/public/objects/Canas2.JPG?itok=j7sGNCq0" andName:@"Años Continuos" andLocation:@"Miami International Airport, Concourse D" andArtist:@"Martinez-Canas, Maria" andInfo:@"Light plays an important role in Años Continuos, a mural composed of sandblasted glass panels filling a 40 by 40 foot atrium space.  Translucent images of maps, travel documents, and cultural symbols are juxtaposed to create a rich visual collage exploring issues relating to personal history, cultural identity, and the passage of time. In speaking of her work, the artist states, photography for me is ‘drawing with light."];
    
    
    
    
    // Category 1 Level 1
    cat1Level1 = [[GameLevel alloc] initWithName: @"Miami International Airport"];
    
    // category 1 level 1 items
    [cat1Level1.items addObject:cat1Level1Item1];
    [cat1Level1.items addObject:cat1Level1Item2];
    [cat1Level1.items addObject:cat1Level1Item3];
    [cat1Level1.items addObject:cat1Level1Item4];
    
    [categories.levels addObject:cat1Level1];
    
    
    
    
    cat2Level1Item1 = [[TreasureHuntItems alloc] initWithImage:@"http://www.nps.gov/ever/planyourvisit/images/FAC-Shark-Valley-Tower-1-NPSPhoto.jpg" andName:@"Shark Valley Visitor Center" andLocation:@"36000 SW 8th Street. Miami, FL 33194" andArtist:@"" andInfo:@"Shark Valley Visitor Center offers educational displays, a park video and informational brochures. Books, postcards, and other souvenirs are available in the gift store. Guided tram tours, bicycle rentals, snacks and soft drinks are available from Shark Valley Tram Tours, Inc.Two short walking trails (one accessible), are located off the main trail for your enjoyment. 8:30 a.m. - 5:00 p.m. Mid-December - Mid-April 9:00 a.m.- 5:00 p.m. Mid-April - Mid-December Hours are subject to change. Contact by phone 305-221-8776.Shark Valley Visitor Center offers educational displays, a park video and informational brochures. Books, postcards, and other souvenirs are available in the gift store."];
    
    cat2Level2Item1 = [[TreasureHuntItems alloc] initWithImage:@"http://www.nps.gov/ever/planyourvisit/images/Ernest-F-Coe-VC.jpg" andName:@"Everglades National Park Ernest Coe Visitor Center" andLocation:@"40001 State Road 9336, Homestead, FL 33034" andArtist:@"" andInfo:@"The Ernest Coe Visitor Center is open 365 days a year. It offers educational displays, orientation films, and informational brochures. Special collections by local artists are often displayed. Books, film, postcards, and insect repellent may be purchased in the adjoining bookstore. A series of popular walking trails begin only a short drive from the visitor center. Restrooms are available. Hours of Operation: Mid December through Mid April 8 a.m. - 5 p.m. Mid April through Mid December 9 a.m. - 5 p.m."];
    
    
    
    cat2Level1 = [[GameLevel alloc] initWithName:@"Shark Valley Visitor Center"];
    [cat2Level1.items addObject:cat2Level1Item1];
    
    cat2Level2 = [[GameLevel alloc] initWithName:@"Everglades National Park Ernest Coe Visitor Center"];
    [cat2Level2.items addObject:cat2Level2Item1];

    
    
    
    
    return myGame;
}

@end
