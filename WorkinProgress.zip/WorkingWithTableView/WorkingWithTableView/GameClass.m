//
//  GameClass.m
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/8/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import "GameClass.h"

@implementation GameClass

@synthesize categories;

- (id) initWithCategories
{
    self = [super init];
    categories = [[NSMutableArray alloc] init];
    
    return self;
}

+ (GameClass *) sharedModel{
    static GameClass *sharedGame = nil;
    if (!sharedGame) {
        sharedGame = [[GameClass alloc] initWithCategories];
    }
    return sharedGame;
}


@end
