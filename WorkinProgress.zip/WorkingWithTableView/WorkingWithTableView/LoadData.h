//
//  LoadData.h
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GameClass.h"
#import "CategoryItems.h"
#import "GameLevel.h"
#import "TreasureHuntItems.h"

@interface LoadData : NSObject{

    GameClass * myGame;
    CategoryItems * categories;
    CategoryItems * categories2;
    CategoryItems * categories3;
    
    //category 1
    GameLevel *cat1Level1;
    GameLevel *cat1Level2;
    GameLevel *cat1Level3;
    GameLevel *cat1Level4;
    
    //category 2
    GameLevel *cat2Level1;
    GameLevel *cat2Level2;
    
    //Cat1 Level 1 Items
    TreasureHuntItems *cat1Level1Item1;
    TreasureHuntItems *cat1Level1Item2;
    TreasureHuntItems *cat1Level1Item3;
    TreasureHuntItems *cat1Level1Item4;
    
    //Cat2 Levels Items
    TreasureHuntItems *cat2Level1Item1;
    TreasureHuntItems *cat2Level2Item1;
}

- (GameClass *) loadData;


@end
