//
//  GameLevel.h
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "CategoryItems.h"

@interface GameLevel : NSObject{
    NSString *levelName;
    NSMutableArray *items;
}

@property (strong, nonatomic) NSString *levelName;
@property (strong, nonatomic) NSMutableArray *items;

- (id) initWithName: (NSString *) name;

@end
