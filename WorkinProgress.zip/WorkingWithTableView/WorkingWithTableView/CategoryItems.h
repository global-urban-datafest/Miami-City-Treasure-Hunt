//
//  CategoryItems.h
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GameLevel.h"

@interface CategoryItems : NSObject{
    NSString *categoryName;
    NSMutableArray *levels;
}

@property (strong, nonatomic) NSString *categoryName;

@property (strong, nonatomic) NSMutableArray *levels;

- (id) initWithName: (NSString *) name;

@end
