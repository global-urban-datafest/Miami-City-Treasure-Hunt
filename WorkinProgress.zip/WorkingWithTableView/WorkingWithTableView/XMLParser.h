//
//  XMLParser.h
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GameClass.h"
#import "CategoryItems.h"
#import "GameLevel.h"
#import "TreasureHuntItems.h"

@interface XMLParser : NSObject <NSXMLParserDelegate>{
    GameClass *game;
    CategoryItems * categories;
    GameLevel *levels;
    TreasureHuntItems *items;
}

-(void) loadDataFromXML;

@property (nonatomic, strong) id parentParserDelegate;

@end
