//
//  CategoryItems.m
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import "CategoryItems.h"

@implementation CategoryItems

@synthesize categoryName, levels;

- (id) initWithName: (NSString *) name{
    self = [super init];
    if (self) {
        levels = [[NSMutableArray alloc] init];
        categoryName = [NSString stringWithString:name];
    }
    return self;
}

@end
