//
//  TreasureHuntItems.m
//  WorkingWithTableView
//
//  Created by manuel alejandro pino on 3/7/15.
//  Copyright (c) 2015 student. All rights reserved.
//

#import "TreasureHuntItems.h"

@implementation TreasureHuntItems

@synthesize image, name, info, location, artist;

- (id) initWithImage: (NSString *) imageI andName: (NSString *) nameI andLocation: (NSString *) locationI andArtist: (NSString *) artistI andInfo: (NSString *) infoI
{
    self = [super init];
    if (self) {
        image = imageI;
        name = nameI;
        info = infoI;
        location = locationI;
        artist = artistI;
    }
    
    return self;
}

@end
