//
//  QRCodeViewController.h
//  ParserDemo
//
//  Created by Bryan De Castro  on 3/7/15.
//  Copyright (c) 2015 Josh Newman. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZbarSDK.h"
#import <Social/Social.h>
#import <Accounts/Accounts.h>

@interface QRCodeViewController : UIViewController <UIImagePickerControllerDelegate,ZBarReaderDelegate>{
    
    IBOutlet UITextView *resultTextView;
}


@property (nonatomic, retain) IBOutlet UITextView *resultTextView;


@property (weak, nonatomic) IBOutlet UIImageView *resultImageView;


@property (nonatomic, retain) UIImagePickerController *imgPicker;

-(IBAction)StartScan:(id) sender;

-(IBAction)postToFacebook:(id) sender;

@end